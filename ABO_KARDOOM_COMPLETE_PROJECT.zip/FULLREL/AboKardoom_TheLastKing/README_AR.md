# أبو كردوم | الملك الأخير
Godot 4.7.2 | com.abokardoum.thelastking

## فتح
Import هذا المجلد في Godot 4.7.2

## GitHub Actions
`.github/workflows/build-apk.yml` — ينشئ debug keystore تلقائيًا ثم يصدّر APK

## تصدير محلي
Project → Export → Android (Use Gradle = Off)
