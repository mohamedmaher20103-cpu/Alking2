# تقرير إصلاح تصدير APK (Termux / AAPT2)

## التشخيص
| البند | التفاصيل |
|--------|-----------|
| العرض | `aapt2-...-linux` + `Syntax error: "(" unexpected` |
| السبب | ثنائي AAPT2 لـ Linux x86_64 على بيئة Android ARM (Termux) |
| ليس السبب | مشاهد اللعبة / webp.import / اسم الحزمة |

## الإصلاح في المستودع
1. الإبقاء على **عدم استخدام Gradle** في `export_presets.cfg`
2. إضافة **GitHub Actions** لبناء APK على Ubuntu
3. توثيق في `docs/TERMUX_AAPT2_AND_APK.md`

## نتيجة اختبار البناء هنا
**لم يُبنَ APK** — بيئة الإصلاح لا تشغّل Godot 4.7.2 + Android SDK كامل.  
لا يوجد ادعاء نجاح APK من هذه الجلسة.

## خطواتك النهائية
- **الأفضل:** GitHub → Actions → Build Android APK
- أو جهاز/PC Linux/Windows مع Godot 4.7.2 وتصدير بدون Gradle
- Termux + Gradle: **غير مدعوم** بسبب AAPT2
