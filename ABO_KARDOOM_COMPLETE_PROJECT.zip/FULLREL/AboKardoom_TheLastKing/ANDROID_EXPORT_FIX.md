# إصلاح تصدير Android — Godot 4.7.2 (Termux / سطح المكتب)

## سبب الخطأ عندك
```
Android build template not installed in the project.
Trying to build from a gradle built template, but no version info...
```

كان مفعّلًا: `gradle_build/use_gradle_build=true`  
وده **يتطلب** تثبيت قالب Android داخل المشروع من القائمة:
`Project → Install Android Build Template...`

## ما تم في المشروع
1. تعطيل Gradle: `gradle_build/use_gradle_build=false`
2. التصدير يعتمد على **Export Templates** العادية (أسهل على Termux)
3. الحزمة: `com.abokardoum.thelastking`
4. الاسم: أبو كردوم | الملك الأخير
5. اتجاه أفقي orientation=0
6. مسار الإخراج: `build/AboKardoom_TheLastKing.apk`
7. `config/features` → 4.7 + Mobile

## خطوات التصدير عندك (إجبارية)

### أ) قوالب التصدير (مرة واحدة)
1. Godot 4.7.2
2. **Editor → Manage Export Templates…**
3. حمّل وثبّت قوالب **4.7.2** (نفس رقم المحرر بالظبط)

### ب) إعداد Android في المحرر
**Editor → Editor Settings → Export → Android**
- اضبط مسار SDK إن طُلب (على Termux غالبًا مسار خاص ببيئة Godot هناك)
- لا تعتمد على `adb` من نظام سطح مكتب غير متوافق

### ج) صدّر
1. **Project → Export…**
2. اختر preset **Android**
3. تأكد أن علامات الخطأ الحمراء اختفت
4. **Export Project** → احفظ `AboKardoom_TheLastKing.apk`

### لو حابب ترجع لـ Gradle لاحقًا
1. أعد `use_gradle_build=true`
2. **Project → Install Android Build Template…**
3. ثم صدّر من جديد  
(أثقل على Termux — غير مُفضّل)

## ما لم يُنفَّذ هنا
- بناء APK فعلي: **لا يوجد Godot 4.7.2 ولا Android SDK/قوالب في بيئة الإصلاح**
- لا يمكن الادعاء أن APK اتبنى بنجاح من هنا

بعد التصدير على جهازك: ثبّت APK مع السماح بالمصادر غير المعروفة.
