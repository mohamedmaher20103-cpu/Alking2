# Termux + AAPT2: سبب الفشل ومسار البناء الصحيح

## الخطأ
```
AAPT2 aapt2-8.6.1-...-linux: Syntax error: "(" unexpected
Execution failed for task ':processStandardDebugResources'
```

## السبب الحقيقي
- عند تفعيل **Gradle build** يحمّل Android Gradle Plugin أداة **aapt2** مبنية لـ **Linux x86_64**.
- Termux يعمل على **Android ARM** (aarch64).
- النظام يحاول تشغيل ثنائي Linux كسكربت shell → الرسالة: `Syntax error: "(" unexpected`.
- هذا **ليس** خطأ في مشاهد اللعبة أو الـ `.webp.import`.

**لا يمكن «إصلاح AAPT2» داخل Termux** باستبدال وهمي؛ الأداة غير متوافقة مع المعمارية.

## الحل في المشروع
1. `export_presets.cfg` → `gradle_build/use_gradle_build=false`
2. التصدير من قوالب Godot الجاهزة (Export Templates) بدون Gradle محلي على الهاتف.
3. مسار بديل موثوق: **GitHub Actions** (Linux x86_64) — الملف:
   `.github/workflows/build-android.yml`

## على Termux (محاولة تصدير بدون Gradle)
1. Godot **4.7.2** بنفس رقم القوالب.
2. Editor → Manage Export Templates → ثبّت 4.7.2.
3. تأكد: Project → Export → Android → **Use Gradle Build = OFF**.
4. Export Project.

إذا Godot على Termux ما زال يفرض Gradle أو يفشل القوالب، استخدم Actions.

## GitHub Actions
1. ارفع المشروع لمستودع GitHub.
2. Actions → **Build Android APK** → Run workflow.
3. بعد الانتهاء: حمّل الـ Artifact `AboKardoom-APK`.

## ما لم يُختبر في بيئة الإصلاح هذه
بناء APK فعلي (لا Godot 4.7.2 + SDK كامل هنا).  
التقرير يصف السبب والحل دون ادعاء APK ناتج من هذه البيئة.

## الحزمة
`com.abokardoum.thelastking`  
الاسم: أبو كردوم | الملك الأخير
